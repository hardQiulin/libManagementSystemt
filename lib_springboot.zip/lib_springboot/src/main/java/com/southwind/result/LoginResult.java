package com.southwind.result;

import lombok.Data;

@Data
public class LoginResult {
    private Object object;
    private String msg;
    private Integer code;
}
