package com.southwind.mapper;

import com.southwind.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author admin
 * @since 2023-03-07
 */
public interface AdminMapper extends BaseMapper<Admin> {

}
